package com.spam_detector.spamdetector.repository;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.spam_detector.spamdetector.model.EmailRecord;

public interface EmailRecordRepository extends MongoRepository<EmailRecord, String> {
    // Additional queries if needed
}
