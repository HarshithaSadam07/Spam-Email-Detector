package com.spam_detector.spamdetector.service;

import org.springframework.stereotype.Service;

@Service
public class SpamDetectionService {

    public boolean isSpam(String emailText) {
        // Your spam detection logic here
        return emailText != null && emailText.toLowerCase().contains("spam");
    }
}
