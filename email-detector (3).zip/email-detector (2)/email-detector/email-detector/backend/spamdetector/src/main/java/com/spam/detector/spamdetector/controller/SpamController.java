package com.spam_detector.spamdetector.controller;

import com.spam_detector.spamdetector.model.EmailRecord;
import com.spam_detector.spamdetector.repository.EmailRecordRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;

import java.util.*;

@RestController
@RequestMapping("/spam-check")
@CrossOrigin(origins = "http://localhost:5174")
public class SpamController {

    @Autowired
    private EmailRecordRepository emailRecordRepository;

    @PostMapping
public ResponseEntity<Map<String, Object>> checkSpam(@RequestBody Map<String, String> payload) {
    String emailText = payload.get("emailText");
    String username = payload.getOrDefault("username", "guest");

    List<EmailRecord> spamRecords = emailRecordRepository.findAll();

    // Simple similarity check using string containment
    int totalSpam = 0;
    int similarSpamMatches = 0;

    for (EmailRecord record : spamRecords) {
        if (record.isSpam()) {
            totalSpam++;
            if (emailText.toLowerCase().contains(record.getEmailText().toLowerCase().substring(0, Math.min(20, record.getEmailText().length())))) {
                similarSpamMatches++;
            }
        }
    }

    double confidence = totalSpam == 0 ? 0.0 : (double) similarSpamMatches / totalSpam;
    boolean isSpam = confidence > 0.5;

    EmailRecord newRecord = new EmailRecord();
    newRecord.setUsername(username);
    newRecord.setEmailText(emailText);
    newRecord.setSpam(isSpam);
    newRecord.setConfidence(confidence);
    emailRecordRepository.save(newRecord);

    Map<String, Object> result = new HashMap<>();
    result.put("isSpam", isSpam);
    result.put("confidence", confidence);
    return ResponseEntity.ok(result);
}

    @GetMapping("/records")
    public ResponseEntity<List<EmailRecord>> getAllEmailRecords() {
        List<EmailRecord> records = emailRecordRepository.findAll();
        return ResponseEntity.ok(records);
    }
}
