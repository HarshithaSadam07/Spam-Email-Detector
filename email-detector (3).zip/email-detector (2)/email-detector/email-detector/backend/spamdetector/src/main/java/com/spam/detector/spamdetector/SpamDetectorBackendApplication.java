package com.spam.detector;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

public class SpamDetectorBackendApplication {
	public static void main(String[] args) {
		SpringApplication.run(SpamDetectorBackendApplication.class, args);
	}
}
