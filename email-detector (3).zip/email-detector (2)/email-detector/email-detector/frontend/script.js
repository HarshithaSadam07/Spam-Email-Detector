document.getElementById('checkBtn').addEventListener('click', () => {
    const emailText = document.getElementById('emailText').value.trim();

    if (!emailText) {
        alert('Please enter some email text.');
        return;
    }

    const resultEl = document.getElementById('result');
    const progressContainer = document.getElementById('progressContainer');
    const progressBar = document.getElementById('progressBar');

    fetch('http://localhost:8081/spam-check/records')
        .then(response => response.json())
        .then(records => {
            let bestMatch = null;
            let highestSimilarity = 0;

            const inputWords = emailText.toLowerCase().split(/\s+/);

            records.forEach(record => {
                const recordWords = record.emailText.toLowerCase().split(/\s+/);
                const commonWords = inputWords.filter(word => recordWords.includes(word));
                const similarity = commonWords.length / inputWords.length;

                if (similarity > highestSimilarity) {
                    highestSimilarity = similarity;
                    bestMatch = record;
                }
            });

            if (bestMatch && highestSimilarity > 0.4) {
                const confidence = Math.round(bestMatch.confidence * 100);
                const isSpam = bestMatch.spam;

                resultEl.innerText = isSpam
                    ? `⚠ Spam Detected: "${bestMatch.emailText}"`
                    : `✅ Looks Safe: "${bestMatch.emailText}"`;

                resultEl.style.color = isSpam ? '#ff4d4d' : '#2ecc71';

                progressBar.style.width = `${confidence}%`;
                progressBar.textContent = `${confidence}%`;
                progressBar.style.background = isSpam ? '#ff4d4d' : '#2ecc71';
                progressContainer.style.display = 'block';
            } else {
                resultEl.textContent = 'No similar email found in database.';
                resultEl.style.color = 'gray';
                progressContainer.style.display = 'none';
            }
        })
        .catch(err => {
            alert('Error fetching from backend API.');
            console.error(err);
        });
});
