import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.naive_bayes import MultinomialNB
from sklearn.pipeline import Pipeline
from sklearn.model_selection import train_test_split
import joblib

# Sample data (you can replace this with a real dataset)
data = {
    'text': [
        "Congratulations, you've won a free iPhone!",
        "Please review the attached invoice.",
        "Click here to claim your prize!",
        "Meeting scheduled for tomorrow.",
        "Win $1000 cash now!",
        "Can we reschedule our call?"
    ],
    'label': [1, 0, 1, 0, 1, 0]  # 1 = spam, 0 = not spam
}

df = pd.DataFrame(data)

# Train/test split
X_train, X_test, y_train, y_test = train_test_split(df['text'], df['label'], test_size=0.2)

# Model pipeline
model = Pipeline([
    ('tfidf', TfidfVectorizer()),
    ('clf', MultinomialNB())
])

# Train
model.fit(X_train, y_train)

# Save model
joblib.dump(model, 'spam_model.joblib')
