from fastapi import FastAPI, Request
from pydantic import BaseModel
import joblib

app = FastAPI()
model = joblib.load('spam_model.joblib')

class EmailText(BaseModel):
    text: str

@app.post("/predict")
def predict_spam(email: EmailText):
    prediction = model.predict([email.text])[0]
    proba = model.predict_proba([email.text])[0][1]  # Confidence of being spam
    return {
        "is_spam": bool(prediction),
        "confidence": round(proba, 2)
    }
